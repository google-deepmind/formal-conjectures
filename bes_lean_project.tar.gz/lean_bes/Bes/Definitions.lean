/-
Definitions.lean — atlas constants and basic sets
-/
import Mathlib.Data.ZMod.Basic
import Mathlib.NumberTheory.LucasLehmer
import Mathlib.Tactic

namespace Bes

/-- Atlas modulus M_840 = 8·3·5·7. -/
def M840 : ℕ := 840

/-- Number of colors (atlas constant). -/
def N_c : ℕ := 3

/-- Number of states (atlas constant). -/
def N_st : ℕ := 4

/-- K = 4·N_c³ - 1 = 107. -/
def K_atlas : ℕ := 107

/-- S = 2K = 214. -/
def S_atlas : ℕ := 214

/-- Frobenius exponent: 29 (with 29² = 841 ≡ 1 mod 840). -/
def FrobExp : ℕ := 29

/-- The Mordell hard residues for the Erdős-Straus conjecture. -/
def Mordell : Finset (ZMod M840) :=
  ({1, 121, 169, 289, 361, 529} : Finset ℕ).image (fun n => (n : ZMod M840))

/-- The Π_Heeg residues from BSD draft. -/
def PiHeeg : Finset (ZMod M840) :=
  ({311, 479, 551, 671, 719, 839} : Finset ℕ).image (fun n => (n : ZMod M840))

/-- The unit prime representatives whose squares produce Mordell. -/
def UnitPrimes : Finset ℕ := {1, 11, 13, 17, 19, 23}

/-- Quadratic residues of (Z/840)* as image of squaring on units. -/
def QR_840 : Finset (ZMod M840) :=
  (Finset.range M840).filter (fun n => Nat.gcd n M840 = 1) |>.image
    (fun n => (n * n : ZMod M840))

end Bes
