-- Bes.lean — Brahim-Erdős-Straus TIGHT theorems
-- Author: Elias Oulad Brahim (ORCID 0009-0009-3302-9532)
import Bes.Definitions
import Bes.Mordell
import Bes.PiHeeg
import Bes.Frobenius
import Bes.GoldbachAnchor
